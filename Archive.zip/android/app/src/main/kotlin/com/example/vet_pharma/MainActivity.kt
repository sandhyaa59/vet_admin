package com.example.vet_pharma

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
