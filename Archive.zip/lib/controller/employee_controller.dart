import 'package:get/get.dart';

class EmployeeController extends GetxController{
  
}